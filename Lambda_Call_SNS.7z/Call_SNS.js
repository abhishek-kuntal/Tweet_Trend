'use strict';

var AWS = require('aws-sdk');

AWS.config.update({
  accessKeyId: '',
  secretAccessKey: '',
  region: 'us-west-2'
});

var sns = new AWS.SNS();

var endpointArn = "arn:aws:sns:us-west-2:261087891618:callLambda"

exports.handler = (event, context, callback) => {
    var payload = {
        default: event.topic
    };
  // then have to stringify the entire message payload
    payload = JSON.stringify(payload);
    sns.publish({
    Message: payload,
    MessageStructure: 'json',
    TargetArn: endpointArn
    }, function(err, data){
        if (err) {
            console.log(err.stack);
            return;
        }
    console.log('push sent to',event.topic);
    console.log(data);
    });
    callback(null,"success"); 
};
